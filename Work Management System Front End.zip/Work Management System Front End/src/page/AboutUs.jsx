import "../page/AboutUs.css";
const AboutUs = () => {
  return (
    <div className="body">
      <div className="text-color ms-5 me-5 mr-5 mt-3">
        <div className="container">
          <div class="row row-cols-2">
            <div class="col">
              <div class="row row-cols-2">
                <div class="col">
                  <br />
                  <span style={{ fontSize: "30px" }}>Nitesh Ghubde</span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i
                      class="fa-sharp fa-solid fa-envelope"
                      style={{ color: "#000000;" }}
                    ></i>{" "}
                    niteshghubde67@gmail.com
                  </span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i class="fa-sharp fa-solid fa-phone"></i> +91- XXX-XX-XXXX
                  </span>
                </div>
                <div class="col">
                  <br />
                  <span style={{ fontSize: "30px" }}>Nikhil Ausekar</span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i
                      class="fa-sharp fa-solid fa-envelope"
                      style={{ color: "#000000;" }}
                    ></i>{" "}
                    nikhilausekar703@gmail.com
                  </span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i class="fa-sharp fa-solid fa-phone"></i> +91- XXX-XX-XXXX
                  </span>
                </div>
                <div class="col">
                  <br />
                  <span style={{ fontSize: "30px" }}>Nikhil Bairagi</span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i
                      class="fa-sharp fa-solid fa-envelope"
                      style={{ color: "#000000;" }}
                    ></i>{" "}
                    anikhilpbairagi11@gmail.com
                  </span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i class="fa-sharp fa-solid fa-phone"></i> +91- XXX-XX-XXXX
                  </span>
                </div>
                <div class="col">
                  <br />
                  <span style={{ fontSize: "30px" }}>Nikita Aurangpure</span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i
                      class="fa-sharp fa-solid fa-envelope"
                      style={{ color: "#000000;" }}
                    ></i>{" "}
                    aurangpurenikita@gmail.com
                  </span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i class="fa-sharp fa-solid fa-phone"></i> +91- XXX-XX-XXXX
                  </span>
                </div>
                <div class="col">
                  <br />
                  <span style={{ fontSize: "30px" }}>Nitin Wadwani</span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i
                      class="fa-sharp fa-solid fa-envelope"
                      style={{ color: "#000000;" }}
                    ></i>{" "}
                    Nitinwadhwani98@gmail.com
                  </span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i class="fa-sharp fa-solid fa-phone"></i> +91- XXX-XX-XXXX
                  </span>
                </div>
                <div class="col">
                  <br />
                  <span style={{ fontSize: "30px" }}>Niyuktee Wani</span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i
                      class="fa-sharp fa-solid fa-envelope"
                      style={{ color: "#000000;" }}
                    ></i>{" "}
                    niyuktiwani12@gmail.com
                  </span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i class="fa-sharp fa-solid fa-phone"></i> +91- XXX-XX-XXXX
                  </span>
                </div>
                <div class="col">
                  <br />
                  <span style={{ fontSize: "30px" }}>Om Kumar</span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i
                      class="fa-sharp fa-solid fa-envelope"
                      style={{ color: "#000000;" }}
                    ></i>{" "}
                    singhom294@gmail.com
                  </span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i class="fa-sharp fa-solid fa-phone"></i> +91- XXX-XX-XXXX
                  </span>
                </div>
                <div class="col">
                  <br />
                  <span style={{ fontSize: "30px" }}>Nikhilesh Pandey</span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i
                      class="fa-sharp fa-solid fa-envelope"
                      style={{ color: "#000000;" }}
                    ></i>{" "}
                    Pandeynikhlesh710@gmail.com
                  </span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i class="fa-sharp fa-solid fa-phone"></i> +91- XXX-XX-XXXX
                  </span>
                </div>
                <div class="col">
                  <br />
                  <span style={{ fontSize: "30px" }}>Satyashil Patil</span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i
                      class="fa-sharp fa-solid fa-envelope"
                      style={{ color: "#000000;" }}
                    ></i>{" "}
                    satyashilpatil911@gmail.com
                  </span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i class="fa-sharp fa-solid fa-phone"></i> +91- XXX-XX-XXXX
                  </span>
                </div>
                <div class="col">
                  <br />
                  <span style={{ fontSize: "30px" }}>Lalit Pamu</span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i
                      class="fa-sharp fa-solid fa-envelope"
                      style={{ color: "#000000;" }}
                    ></i>
                    lalithp131@gmail.com
                  </span>
                  <br />
                  <span style={{ fontSize: "20px" }}>
                    <i class="fa-sharp fa-solid fa-phone"></i> +91- XXX-XX-XXXX
                  </span>
                </div>
              </div>
              <br /><br />
              <h3>Address:</h3><i class="fa-solid fa-location-dot"></i> <span>Plot No. 6 & 7, Hardware Park, Sy No. 1/1, Srisailam Highway, <br />
                Pahadi Shareef Via (Keshavagiri Post) Hyderabad - 501510
                Telangana(India) <br />
                <i class="fa-sharp fa-solid fa-phone"></i>+91-9100034446/7/8
              </span>
            </div>
            <div class="col">
              <div class="d-flex" style={{ height: "50rem" }}>
                <div class="vr"></div>
                <div class="container">
                  <h2>Contact Us</h2>
                  <form>
                    <label for="fname">First Name</label>
                    <input
                      type="text"
                      id="fname"
                      name="firstname"
                      placeholder="Your name.."
                    />

                    <label for="lname">Last Name</label>
                    <input
                      type="text"
                      id="lname"
                      name="lastname"
                      placeholder="Your last name.."
                    />

                    <label for="country">Country</label>
                    <select id="country" name="country">
                      <option value="India" selected>India</option>
                      <option value="canada">Canada</option>
                      <option value="usa">USA</option>
                    </select>

                    <label for="subject">Subject</label>
                    <textarea
                      id="subject"
                      name="subject"
                      placeholder="Write something.."
                      style={{ height: "200px" }}
                    ></textarea>

                    <input type="submit" value="Submit" />
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;