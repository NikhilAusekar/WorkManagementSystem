import React from 'react';
import './ContactUs.css';

const ContactUs = () => {
  return (
    <div className="contact-us-container">
      <div className="container mt-5">
        <h1>Contact Us</h1>
        <div className="row">
          <div className="col-md-6">
            <h2>Contact Information</h2>
            <p>
              <strong>Address:</strong> C-DAC Hyderabad Plot No. 6 & 7, Hardware Park, Sy No. 1/1, Hyderabad, Telangana 501510
            </p>
            <p>
              <strong>Phone:</strong> +91- 9130558387, 7385105131, 7378459771
            </p>
            <p>
              <strong>Email:</strong> workmanagementsystem123@gmail.com
            </p>
            <p>
              <strong>Hours of Operation:</strong> Mon-Fri: 9 AM - 6 PM
            </p>
          </div>
          <div className="col-md-6">
            <h2>Message Us</h2>
            <p>
              If you have any questions or inquiries, please feel free to get in touch with us using the contact information provided above.
            </p>
            <p>
              We are here to assist you with any queries you might have regarding our work management system application.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
